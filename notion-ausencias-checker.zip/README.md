# Notion Ausências Checker

Verifica conflitos entre reuniões e ausências cadastradas em duas bases do Notion, usando GitHub Actions.

Rodando automaticamente a cada 5 minutos!
